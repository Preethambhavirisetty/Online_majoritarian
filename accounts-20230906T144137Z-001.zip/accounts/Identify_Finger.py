import cv2
import numpy as np
import os
from django.conf.urls.static import static

def compareFinger(image_name,file):
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
    image_dir = os.path.join(BASE_DIR,"static/media/fingerprints")
    s = 0
    for i in range(len(image_name)):
        if image_name[i] == '/':
            s = i
            break
    image_name = image_name[s+1:]
    test_original = cv2.imread("accounts/static/media/test/"+image_name)
    s = 0
    for i in range(len(file)):
        if file[i] == "/":
            s=i
            break
    file = file[s+1:]
    fingerprint_database_image = cv2.imread("./accounts/static/media/fingerprints/"+file)
    sift = cv2.xfeatures2d.SIFT_create()

    keypoints_1, description_1 = sift.detectAndCompute(test_original,None)
    keypoints_2, description_2 = sift.detectAndCompute(fingerprint_database_image,None)

    matches = cv2.FlannBasedMatcher(dict(algorithm=1,trees=10),dict()).knnMatch(description_1,description_2,k=2)

    match_points = []

    for p, q in matches:
        if p.distance < 0.1*q.distance:
            match_points.append(p)
    keypoints = 0
    if len(keypoints_1) <= len(keypoints_2):
        keypoints = len(keypoints_1)
    else:
        keypoints = len(keypoints_2)
    
    if (len(match_points)/keypoints)>0.95:
        if int(len(match_points)/keypoints*100) == 100:
            return True
    return False